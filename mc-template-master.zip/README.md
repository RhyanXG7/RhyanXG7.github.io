<h1 align="center">.+* <a href="https://gh.imlucas.com.br/template-mc-2020">LIVE DEMO</a> | <a href="https://gh.imlucas.com.br/template-mc-2020/template-mc-2020.zip">DOWNLOAD</a> *+.</h1>
<p align="center">6 páginas | Copiar IP ao clicar | Players online (e MOTD) | Widget de rede social | Responsivo | Fácil de editar</p>

![](https://i.imgur.com/NLbaydF.png)

<h2 align="center">.+* Dicas para editar *+.</h2>

- No topo do arquivo `assets/css/style.css`, é possível alterar a cor principal (e uma versão mais escura dela), que por padrão é azul
- No mesmo local do mesmo arquivo, também é possível centralizar a logo à esquerda, no meio ou à direita
- Caso a porta do seu servido NÃO seja 25565, vá até a linha 24 do arquivo `assets/js/scripts.js` e altere a porta
- Ao alterar o IP do servidor na linha 52 de cada página, já será possível copiar e ver o status do mesmo
- É possível usar classes como `cor-b` e `cor-6` para usar as cores do Minecraft para colorir seu texto
- Você é completamente livre para tirar meus créditos do rodapé, mas se deixar eu agradeço muito